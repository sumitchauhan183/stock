<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;
use App\Classes\Email;
use Exception;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return "Wrong page";
    }

    public function checkEmail(Request $request)
    {
        $input = $request->all();
        if(isset($input['email'])):
            $check = Admin::where('email',$input['email'])->count();
            if($check>0):
                return json_encode([
                    'error'=>false
                ]);
            else:
                return json_encode([
                    'error'=>true,
                    'message'=>'This email is not authorised for Administrative use'
                ]);
            endif;
        else:
            return json_encode([
                'error'=>true,
                'message'=>'Email id is required'
            ]);
        endif;
    }


    public function login(Request $request)
    {
        $input = $request->all();
        $email  = Admin::where('email',$input['email'])->count();
        if($email<1):
            return json_encode([
                'error'=>true,
                'message'=>'Email id not exist'
            ]);
        endif;
        $check = Admin::where('email',$input['email'])
                ->get()->first()->toArray();
        if(Hash::check($input['password'], $check['password'])):
            $admin_id = $check['admin_id'];
            
            $token = $this->generateToken($admin_id);
            Admin::where('admin_id',$admin_id)->update(['login_token'=>$token]);
            $admin = Admin::where('admin_id',$admin_id)
                ->get()->first()->toArray();
            session()->put('admin',[
                "type"=>'admin',
                "data"=>$admin,
                "token" => $token
            ]);
            
            return json_encode([
                'error'=>false,
                'message'=>'Login Successful',
                'admin_id'=> $admin_id,
                'token'=> $token
            ]);
        else:
            return json_encode([
                'error'=>true,
                'message'=>'Please check your password'
            ]); 
        endif;  
    }



    private function generateToken($admin_id)
    {
        $token = md5($admin_id.time());
        Admin::where('admin_id',$admin_id)
                ->update(['login_token'=>$token]);
        return $token;
    }    
}
