<div class="sidebar-nav scrollbar scroll_light">
	<ul class="metismenu " id="sidebarNav">
		<li>
			<a href="client-name.php" aria-expanded="false">
				<span class="nav-title">Client Name</span>
			</a> 
		</li>
		<li>
			<a href="javascript:void(0)" aria-expanded="false">
				<span class="nav-title">Email Address</span>
			</a> 
		</li>
		<li>
			<a href="javascript:void(0)" aria-expanded="false">
				<span class="nav-title">Find Value Stocks</span>
				<small>Expiry Date 12/4/2021</small>
			</a> 
		</li>
		<li>
			<a href="optimize.php" aria-expanded="false">
				<span class="nav-title">Optimize Investment Mix</span>
				<!-- <span class="nav-title">Add Another Tool</span> -->
			</a> 
		</li>
		<li>
			<a href="javascript:void(0)" aria-expanded="false">
				<span class="nav-title">Setting</span>
			</a> 
		</li>		
	</ul>
</div>