

    <!-- plugins -->
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/vendors.js" type="text/javascript"></script>
    <script src="js/app.js" type="text/javascript"></script>
    <script src="js/canvasjs.min.js"> </script>
    <!-- Modal Efects -->
    <script src='js/velocity.min.js'></script>
    <script src='js/velocity.ui.min.js'></script>
    <script src="js/custom.js" type="text/javascript"></script>


</body>


</html>